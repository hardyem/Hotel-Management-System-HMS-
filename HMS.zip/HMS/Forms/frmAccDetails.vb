﻿Imports System.Data.SqlClient

Public Class frmAccDetails

    Sub Reset()
        lblSID.Text = ""
        lblEFN.Text = ""
        txtAccNo.Text = ""
        txtAHN.Text = ""
        'cmbProdType.SelectedIndex = -1
        txtSAmt.Text = ""
        'dtpExpDate.Text = Today
        cmbPost.Text = ""
        'txtDesc.Text = ""
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        txtAHN.Focus()
    End Sub

    Sub fillPost()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(Post) FROM Position", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbPost.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbPost.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If lblSID.Text = "" Then
            MessageBox.Show("Please load staff ID", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblSID.Focus()
            Return
        End If
        If cmbPost.Text = "" Then
            MessageBox.Show("Please select position", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbPost.Focus()
            Return
        End If
        If txtAccNo.Text = "" Then
            MessageBox.Show("Please enter account number", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtAccNo.Focus()
            Return
        End If
        If lblEFN.Text = "" Then
            MessageBox.Show("Please load employee full name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblEFN.Focus()
            Return
        End If
        If txtSAmt.Text = "" Then
            MessageBox.Show("Please enter employee salary", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSAmt.Focus()
            Return
        End If

        Try
            con = New SqlConnection(cs)
            con.Open()
            Dim ct As String = "select StaffID  from AccDetail where StaffID=@d1"
            cmd = New SqlCommand(ct)
            cmd.Parameters.AddWithValue("@d1", lblSID.Text)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                MessageBox.Show("Staff Account details Already Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                'lblSID.Text = ""
                'lblSID.Focus()
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                Return
            End If

            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "insert into AccDetail (StaffID, EFName, AccHN, AccNo, Salary, Post) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
            cmd = New SqlCommand(cb)
            cmd.Parameters.AddWithValue("@d1", lblSID.Text)
            cmd.Parameters.AddWithValue("@d2", lblEFN.Text)
            cmd.Parameters.AddWithValue("@d3", txtAHN.Text)
            cmd.Parameters.AddWithValue("@d4", txtAccNo.Text)
            cmd.Parameters.AddWithValue("@d5", txtSAmt.Text)
            cmd.Parameters.AddWithValue("@d6", cmbPost.Text)
            'cmd.Parameters.AddWithValue("@d7", txtCPrice.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()

            Dim st As String = "added the new staff account details'" & lblSID.Text & "'"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully Saved", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSave.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If lblSID.Text = "" Then
            MessageBox.Show("Please load staff ID", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblSID.Focus()
            Return
        End If
        If cmbPost.Text = "" Then
            MessageBox.Show("Please select position", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbPost.Focus()
            Return
        End If
        If txtAccNo.Text = "" Then
            MessageBox.Show("Please enter account number", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtAccNo.Focus()
            Return
        End If
        If lblEFN.Text = "" Then
            MessageBox.Show("Please load employee full name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblEFN.Focus()
            Return
        End If
        If txtSAmt.Text = "" Then
            MessageBox.Show("Please enter employee salary", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSAmt.Focus()
            Return
        End If

        Try
            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "Update AccDetail set StaffID=@d1, EFName=@d2, AccHN=@d3, AccNo=@d4, Salary=@d5, Post=@d6 where StaffID=@d7"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", lblSID.Text)
            cmd.Parameters.AddWithValue("@d2", lblEFN.Text)
            cmd.Parameters.AddWithValue("@d3", txtAHN.Text)
            cmd.Parameters.AddWithValue("@d4", txtAccNo.Text)
            cmd.Parameters.AddWithValue("@d5", txtSAmt.Text)
            cmd.Parameters.AddWithValue("@d6", cmbPost.Text)
            'cmd.Parameters.AddWithValue("@d7", txtCPrice.Text)

            cmd.Parameters.AddWithValue("@d7", txtStaffName.Text)
            'cmd.Parameters.AddWithValue("@d10", txtQtyName.Text)
            cmd.ExecuteReader()
            con.Close()

            Dim st As String = "updated the staff account '" & lblSID.Text & "'details"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully updated", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub DeleteRecord()

        Try
            Dim RowsAffected As Integer = 0

            con = New SqlConnection(cs)
            con.Open()
            Dim cq As String = "delete from AccDetail where StaffID=@d8"
            cmd = New SqlCommand(cq)
            cmd.Parameters.AddWithValue("@d8", txtStaffName.Text)
            'cmd.Parameters.AddWithValue("@d9", txtProdTypeName.Text)
            cmd.Connection = con
            RowsAffected = cmd.ExecuteNonQuery()
            If RowsAffected > 0 Then
                Dim st As String = "deleted the staff account details '" & lblSID.Text & "'"
                LogFunc(lblUser.Text, st)
                MessageBox.Show("Successfully deleted", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Getdata()
                Reset()
            Else
                MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                If lblSet.Text = "Payroll" Then
                    Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                    Me.Hide()
                    frmPayroll.Show()
                    frmPayroll.lblAHN.Text = dr.Cells(1).Value.ToString()
                    frmPayroll.lblSID.Text = dr.Cells(0).Value.ToString()
                    frmPayroll.lblSAmt.Text = dr.Cells(3).Value.ToString()
                    'Dim data As Byte() = DirectCast(dr.Cells(16).Value, Byte())
                    'Dim ms As New MemoryStream(data)
                    'frmStaff.Picture.Image = Image.FromStream(ms)

                    frmPayroll.btnDelete.Enabled = False
                    frmPayroll.btnUpdate.Enabled = False
                    frmPayroll.btnSave.Enabled = True
                    lblSet.Text = ""
                    If (rdr IsNot Nothing) Then
                        rdr.Close()
                    End If
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    lblSet.Text = ""
                Else
                    Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                    lblSID.Text = dr.Cells(0).Value.ToString()
                    txtAHN.Text = dr.Cells(1).Value.ToString()
                    txtAccNo.Text = dr.Cells(2).Value.ToString()
                    txtSAmt.Text = dr.Cells(3).Value.ToString()
                    lblEFN.Text = dr.Cells(4).Value.ToString()
                    cmbPost.Text = dr.Cells(5).Value.ToString()
                    'txtDesc.Text = dr.Cells(6).Value.ToString()
                    txtStaffName.Text = dr.Cells(0).Value.ToString()
                    btnUpdate.Enabled = True
                    btnDelete.Enabled = True
                    btnSave.Enabled = False
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub
    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID), RTRIM(AccHN), RTRIM(AccNO), RTRIM(Salary), RTRIM(EFName), RTRIM(Post) from AccDetail order by StaffID", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        lblSet.Text = ""
        Me.Close()
    End Sub

    Private Sub frmProduct_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
        fillPost()
        AcceptButton = btnSave
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Me.Reset()
        frmStaffRecord.lblSet.Text = "Staff"
        frmStaffRecord.Reset()
        frmStaffRecord.ShowDialog()
    End Sub
End Class