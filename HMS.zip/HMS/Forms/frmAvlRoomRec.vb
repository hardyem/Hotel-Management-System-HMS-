﻿Imports System.Data.SqlClient
Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmAvlRoomRec

    Sub Reset()
        TextBox2.Text = ""
        TextBox1.Text = ""
        Getdata()
    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(RNo) as [Room No], RTRIM(RType) as [Room Type], RTRIM(RLocation) as [Room Location], RTRIM(Price) as [Price] FROM AvlRoom order by RNo", con)
            'cmd = New SqlCommand("SELECT RTRIM(ProductName) as [Product Name], RTRIM(Type) as [Product Type], RTRIM(Desc) as [Description], RTRIM(UnitPrice) as [UnitPrice], RTRIM(BulkPrice) as [Bulk Price], RTRIM(ExpDate) as [Expiry Date], RTRIM(Qty) as [Avl. Qty.] FROM AvlRoom INNER JOIN Temp_Stock ON AvlRoom.ProductName=Temp_Stock.ProductName and AvlRoom.Type=Temp_Stock.ProdType order by ProductName, Type, ExpDate", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "AvlRoom")
            dgw.DataSource = ds.Tables("AvlRoom").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmCheckInRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(RNo) as [Room No], RTRIM(RType) as [Room Type], RTRIM(RLocation) as [Room Location], RTRIM(Price) as [Price] FROM AvlRoom where RNo like '%" & TextBox2.Text & "%' order by RNo", con)
            Dim myDA As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "AvlRoom")
            dgw.DataSource = myDataSet.Tables("AvlRoom").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub btnExportExcel_Click(sender As Object, e As EventArgs) Handles btnExportExcel.Click
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application
        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgw.RowCount
            colsTotal = dgw.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgw.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgw.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub dgw_MouseClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                If lblSet.Text = "AvlRoom" Then
                    Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                    'frmCheckIn.Reset()
                    frmCheckIn.Show()
                    Me.Hide()
                    frmCheckIn.lblRNo.Text = dr.Cells(0).Value.ToString()
                    frmCheckIn.lblRType.Text = dr.Cells(1).Value.ToString()
                    frmCheckIn.lblRLoc.Text = dr.Cells(2).Value.ToString()
                    frmCheckIn.lblRPrice.Text = dr.Cells(3).Value.ToString()
                    'frmCheckIn.lblGFN.Text = dr.Cells(2).Value.ToString()

                    'con = New SqlConnection(cs)
                    'con.Open()
                    'Dim sql As String = "SELECT RTRIM(Productname),RTRIM(ProdType),Sales_Qty,PPUnit,Tot_Amt from Sales_Data where S_No=" & dr.Cells(0).Value & ""
                    'cmd = New SqlCommand(sql, con)
                    'rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    'frmSales.DataGridView1.Rows.Clear()
                    'While (rdr.Read() = True)
                    'frmSales.DataGridView1.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4))
                    'End While
                    con.Close()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(RNo) as [Room No], RTRIM(RType) as [Room Type], RTRIM(RLocation) as [Room Location], RTRIM(Price) as [Price] FROM AvlRoom where RType like '%" & TextBox1.Text & "%' order by RNo", con)
            Dim myDA As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "AvlRoom")
            dgw.DataSource = myDataSet.Tables("AvlRoom").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            'Dim rpt As New rptProduct() 'The report you created.
            Dim myConnection As SqlConnection
            Dim MyCommand, MyCommand1 As New SqlCommand()
            Dim myDA, myDA1 As New SqlDataAdapter()
            Dim myDS As New DataSet 'The DataSet you created.
            myConnection = New SqlConnection(cs)
            MyCommand.Connection = myConnection
            MyCommand1.Connection = myConnection
            MyCommand.CommandText = "Select * from AvlRoom where RNo Like '%" & TextBox2.Text & "%' order by RNo"
            MyCommand.CommandType = CommandType.Text
            myDA.SelectCommand = MyCommand
            myDA.Fill(myDS, "AvlRoom")
            'rpt.SetDataSource(myDS)
            ' frmReport.CrystalReportViewer1.ReportSource = rpt
            ' frmReport.ShowDialog()
            myConnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub

    'Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
    '   Getdata()
    'End Sub
End Class