﻿Imports System.Data.SqlClient

Public Class frmCheckIn
    Sub Reset()
        lblRLoc1.Text = ""
        lblRType1.Text = ""
        lblRNo1.Text = ""
        lblRPrice1.Text = ""
        lblRLoc.Text = ""
        lblRType.Text = ""
        lblGFN.Text = ""
        txtNDay.Text = ""
        cmbPayM.Text = ""
        lblRNo.Text = ""
        lblRPrice.Text = ""
        txtAmtPaid.Text = ""
        txtNoG.Text = ""
        cmbCIT.Text = ""
        'cmbProdType.SelectedIndex = -1
        dtpCOD.Text = Today
        cmbCOT.Text = ""
        dtpCID.Text = Today
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        txtNDay.Focus()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If lblGFN.Text = "" Then
            MessageBox.Show("Load guest name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblGFN.Focus()
            Return
        End If
        If lblRNo.Text = "" Then
            MessageBox.Show("Load room number", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            'lblRNo.Focus()
            Return
        End If
        If txtAmtPaid.Text = "" Then
            MessageBox.Show("Please enter amount paid", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtAmtPaid.Focus()
            Return
        End If
        If cmbCIT.Text = "" Then
            MessageBox.Show("Please select check in time", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbCIT.Focus()
            Return
        End If
        If dtpCID.Text = "" Then
            MessageBox.Show("Please select check in date", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            dtpCID.Focus()
            Return
        End If
        Try
            con = New SqlConnection(cs)
            con.Open()
            Dim ct As String = "select RoomNo from CheckIn where RoomNo=@d1"
            cmd = New SqlCommand(ct)
            cmd.Parameters.AddWithValue("@d1", lblRNo.Text)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                MessageBox.Show("Room is already occupied", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                'txtNDay.Text = ""
                'txtNDay.Focus()
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                Return
            End If

            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "insert into CheckIN(GuestFN, NoDay, RoomNo, RoomPrice, AmtPaid, PayMethod, NoGuest, CID, CIT, COD, COT,RType,RLoc) VALUES (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12,@d13)"
            cmd = New SqlCommand(cb)
            cmd.Parameters.AddWithValue("@d1", lblGFN.Text)
            cmd.Parameters.AddWithValue("@d2", txtNDay.Text)
            cmd.Parameters.AddWithValue("@d3", lblRNo.Text)
            cmd.Parameters.AddWithValue("@d4", lblRPrice.Text)
            cmd.Parameters.AddWithValue("@d5", txtAmtPaid.Text)
            cmd.Parameters.AddWithValue("@d6", cmbPayM.Text)
            cmd.Parameters.AddWithValue("@d7", txtNoG.Text)
            cmd.Parameters.AddWithValue("@d8", dtpCID.Value.Date)
            cmd.Parameters.AddWithValue("@d9", cmbCIT.Text)
            cmd.Parameters.AddWithValue("@d10", dtpCOD.Value.Date)
            cmd.Parameters.AddWithValue("@d11", cmbCOT.Text)
            cmd.Parameters.AddWithValue("@d12", lblRType.Text)
            cmd.Parameters.AddWithValue("@d13", lblRLoc.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()
            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            con = New SqlConnection(cs)
            con.Open()

            Dim cb1 As String = "insert into CheckINRec(GuestFN, NoDay, RoomNo, RoomPrice, AmtPaid, PayMethod, NoGuest, CID, CIT, COD, COT,RType,RLoc) VALUES (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12,@d13)"
            cmd = New SqlCommand(cb1)
            cmd.Parameters.AddWithValue("@d1", lblGFN.Text)
            cmd.Parameters.AddWithValue("@d2", txtNDay.Text)
            cmd.Parameters.AddWithValue("@d3", lblRNo.Text)
            cmd.Parameters.AddWithValue("@d4", lblRPrice.Text)
            cmd.Parameters.AddWithValue("@d5", txtAmtPaid.Text)
            cmd.Parameters.AddWithValue("@d6", cmbPayM.Text)
            cmd.Parameters.AddWithValue("@d7", txtNoG.Text)
            cmd.Parameters.AddWithValue("@d8", dtpCID.Value.Date)
            cmd.Parameters.AddWithValue("@d9", cmbCIT.Text)
            cmd.Parameters.AddWithValue("@d10", dtpCOD.Value.Date)
            cmd.Parameters.AddWithValue("@d11", cmbCOT.Text)
            cmd.Parameters.AddWithValue("@d12", lblRType.Text)
            cmd.Parameters.AddWithValue("@d13", lblRLoc.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()
            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            con = New SqlConnection(cs)
            con.Open()
            Dim cq As String = "delete from AvlRoom where RNo=@d8"
            cmd = New SqlCommand(cq)
            cmd.Parameters.AddWithValue("@d8", lblRNo.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()
            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            Dim st As String = "room assigned to'" & lblGFN.Text & "'"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully Saved", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSave.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If lblGFN.Text = "" Then
            MessageBox.Show("Load guest name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblGFN.Focus()
            Return
        End If
        If lblRNo.Text = "" Then
            MessageBox.Show("Load room number", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            'lblRNo.Focus()
            Return
        End If
        If txtAmtPaid.Text = "" Then
            MessageBox.Show("Please enter amount paid", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtAmtPaid.Focus()
            Return
        End If
        If cmbCIT.Text = "" Then
            MessageBox.Show("Please select check in time", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbCIT.Focus()
            Return
        End If
        If dtpCID.Text = "" Then
            MessageBox.Show("Please select check in date", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            dtpCID.Focus()
            Return
        End If

        Try
            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "Update CheckIN set GuestFN=@d1, NoDay=@d2, RoomNo=@d3, RoomPrice=@d4, AmtPaid=@d5, PayMethod=@d6, NoGuest=@d7, CID=@d8, CIT=@d9, COD=@d10, COT=@d11 where RoomNo=@d12"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", lblGFN.Text)
            cmd.Parameters.AddWithValue("@d2", txtNDay.Text)
            cmd.Parameters.AddWithValue("@d3", lblRNo.Text)
            cmd.Parameters.AddWithValue("@d4", lblRPrice.Text)
            cmd.Parameters.AddWithValue("@d5", txtAmtPaid.Text)
            cmd.Parameters.AddWithValue("@d6", cmbPayM.Text)
            cmd.Parameters.AddWithValue("@d7", txtNoG.Text)
            cmd.Parameters.AddWithValue("@d8", dtpCID.Value.Date)
            cmd.Parameters.AddWithValue("@d9", cmbCIT.Text)
            cmd.Parameters.AddWithValue("@d10", dtpCOD.Text)
            cmd.Parameters.AddWithValue("@d11", cmbCOT.Text)
            cmd.Parameters.AddWithValue("@d12", txtCIName.Text)
            cmd.ExecuteReader()
            con.Close()

            Dim st As String = "updated the Check In '" & lblRNo.Text & "'room details"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully updated", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub DeleteRecord()

        Try
            Dim RowsAffected As Integer = 0

            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            con = New SqlConnection(cs)
            con.Open()
            Dim cb As String = "insert into AvlRoom(RNo, RType, RLocation, Price) VALUES (@d1,@d2,@d3,@d4)"
            cmd = New SqlCommand(cb)
            cmd.Parameters.AddWithValue("@d1", lblRNo1.Text)
            cmd.Parameters.AddWithValue("@d2", lblRType1.Text)
            cmd.Parameters.AddWithValue("@d3", lblRLoc1.Text)
            cmd.Parameters.AddWithValue("@d4", lblRPrice1.Text)
            'cmd.Parameters.AddWithValue("@d12", txtST_ID.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()
            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            con = New SqlConnection(cs)
            con.Open()
            Dim cq As String = "delete from CheckIN where RoomNo=@d8"
            cmd = New SqlCommand(cq)
            cmd.Parameters.AddWithValue("@d8", lblRNo1.Text)
            cmd.Connection = con
            RowsAffected = cmd.ExecuteNonQuery()
            If RowsAffected > 0 Then
                Dim st As String = "Check out from room '" & lblRNo1.Text & "'"
                LogFunc(lblUser.Text, st)
                MessageBox.Show("Successfully checked out from room", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Getdata()
                Reset()
            Else
                MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                txtCIName.Text = dr.Cells(0).Value.ToString()
                ' lblGFN.Text = dr.Cells(0).Value.ToString()
                ' txtNDay.Text = dr.Cells(1).Value.ToString()
                '  cmbPayM.Text = dr.Cells(2).Value.ToString()
                'txtNoG.Text = dr.Cells(7).Value.ToString()
                ' lblRPrice.Text = dr.Cells(4).Value.ToString()
                '++++++++++++++++++++++++++++++++++++++++++++++++
                ' lblRNo.Text = dr.Cells(0).Value.ToString()
                ' cmbCIT.Text = dr.Cells(3).Value.ToString()
                '  txtAmtPaid.Text = dr.Cells(1).Value.ToString()
                ' dtpCID.Text = dr.Cells(2).Value.ToString()
                ' dtpCOD.Text = dr.Cells(4).Value.ToString()
                ' cmbCOT.Text = dr.Cells(5).Value.ToString()
                '++++++++++++++++++++++++++++++++++++++++++++++++
                lblRNo1.Text = dr.Cells(0).Value.ToString()
                lblRType1.Text = dr.Cells(6).Value.ToString()
                lblRLoc1.Text = dr.Cells(7).Value.ToString()
                lblRPrice1.Text = dr.Cells(8).Value.ToString()
                btnUpdate.Enabled = True
                btnDelete.Enabled = True
                btnSave.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub
    Public Sub GetdataS()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(RoomNo), RTRIM(AmtPaid), RTRIM(CID), RTRIM(CIT), RTRIM(COD), RTRIM(COT), RTRIM(RType), RTRIM(RLoc), RTRIM(RoomPrice) from CheckIN WHERE CID='" & dtpCID.Value & "' order by RoomNo", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(RoomNo), RTRIM(AmtPaid), RTRIM(CID), RTRIM(CIT), RTRIM(COD), RTRIM(COT), RTRIM(RType), RTRIM(RLoc), RTRIM(RoomPrice) from CheckIN order by RoomNo", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmCheckIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetdataS()
        AcceptButton = btnSave
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Me.Reset()
        frmGuestRec.lblSet.Text = "Guest"
        frmGuestRec.Reset()
        frmGuestRec.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'Me.Reset()
        frmRoomRec.lblSet.Text = "Room"
        frmRoomRec.Reset()
        frmRoomRec.ShowDialog()
    End Sub

    Private Sub DtpCID_ValueChanged(sender As Object, e As EventArgs) Handles dtpCID.ValueChanged
        GetdataS()
    End Sub
End Class