﻿Imports System.Data.SqlClient

Public Class frmDiscount
    Sub Reset()
        cmbDept.Text = ""
        txtDiscAmt.Text = ""
        dtpDate.Value = Today
        txtCom.Text = ""
        'cmbProdType.SelectedIndex = -1
        'txtDesc.Text = ""
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        cmbDept.Focus()
    End Sub

    Sub fillDept()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(Dept) FROM Department", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbDept.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbDept.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If cmbDept.Text = "" Then
            MessageBox.Show("Please select department", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbDept.Focus()
            Return
        End If
        If txtDiscAmt.Text = "" Then
            MessageBox.Show("Please enter discount amount", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtDiscAmt.Focus()
            Return
        End If
        If dtpDate.Text = "" Then
            MessageBox.Show("Please select date", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            dtpDate.Focus()
            Return
        End If


        Try

            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "insert into Discount (Dept, DiscAmt, DiscDate, Comment) VALUES (@d1,@d2,@d3,@d4)"
            cmd = New SqlCommand(cb)
            cmd.Parameters.AddWithValue("@d1", cmbDept.Text)
            cmd.Parameters.AddWithValue("@d2", txtDiscAmt.Text)
            cmd.Parameters.AddWithValue("@d3", dtpDate.Value)
            cmd.Parameters.AddWithValue("@d4", txtCom.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()

            Dim st As String = "added the new discount'" & cmbDept.Text & "'"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully Saved", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSave.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub dgw_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                cmbDept.Text = dr.Cells(0).Value.ToString()
                dtpDate.Text = dr.Cells(2).Value.ToString()
                txtCom.Text = dr.Cells(3).Value.ToString()
                txtDiscAmt.Text = dr.Cells(1).Value.ToString()
                'txtDesc.Text = dr.Cells(6).Value.ToString()
                txtDiscName.Text = dr.Cells(0).Value.ToString()
                btnUpdate.Enabled = True
                btnDelete.Enabled = True
                btnSave.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub
    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Dept), RTRIM(DiscAmt), RTRIM(DiscDate), RTRIM(Comment) from Discount order by Dept", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmProduct_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
        fillDept()
        AcceptButton = btnSave
    End Sub

End Class