﻿Imports System.Data.SqlClient

Public Class frmGymReg
    Sub Reset()
        txtCName.Text = ""
        dtpRegDate.Text = ""
        dtpEndDate.Text = ""
        txtPNo.Text = ""
        cmbRegType.SelectedIndex = -1
        txtAmtPaid.Text = ""
        'dtpExpDate.Text = Today
        cmbDur.Text = ""
        cmbRegType.Text = ""
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        txtCName.Focus()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If txtAmtPaid.Text = "" Then
            MessageBox.Show("Please enter amount paid", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtAmtPaid.Focus()
            Return
        End If
        If txtCName.Text = "" Then
            MessageBox.Show("Please enter full name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCName.Focus()
            Return
        End If
        If txtPNo.Text = "" Then
            MessageBox.Show("Please enter contact number", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPNo.Focus()
            Return
        End If

        Try

            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "insert into Gym (Duration, GymCName, RegDate, GPNo, EndDate, AmtPaid, Regtype) VALUES (@d1,@d2,@d3,@d4,@d5,@d6,@d7)"
            cmd = New SqlCommand(cb)
            cmd.Parameters.AddWithValue("@d1", cmbDur.Text)
            cmd.Parameters.AddWithValue("@d2", txtCName.Text)
            cmd.Parameters.AddWithValue("@d3", dtpRegDate.Value.Date)
            cmd.Parameters.AddWithValue("@d4", txtPNo.Text)
            cmd.Parameters.AddWithValue("@d5", dtpEndDate.Value.Date)
            cmd.Parameters.AddWithValue("@d6", txtAmtPaid.Text)
            cmd.Parameters.AddWithValue("@d7", cmbRegType.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()

            Dim st As String = "added the new customer'" & txtCName.Text & "'"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully Saved", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSave.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If txtAmtPaid.Text = "" Then
            MessageBox.Show("Please select Gym gender", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtAmtPaid.Focus()
            Return
        End If
        If txtCName.Text = "" Then
            MessageBox.Show("Please enter Gym full name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCName.Focus()
            Return
        End If
        If txtPNo.Text = "" Then
            MessageBox.Show("Please enter contact number", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPNo.Focus()
            Return
        End If

        Try
            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "Update Gym set Duration=@d1, GymCName=@d2, RegDate=@d3, PNo=@d4, EndDate=@d5, AmtPaid=@d6 where Duration=@d7"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", cmbDur.Text)
            cmd.Parameters.AddWithValue("@d2", txtCName.Text)
            cmd.Parameters.AddWithValue("@d3", dtpRegDate.Text)
            cmd.Parameters.AddWithValue("@d4", txtPNo.Text)
            cmd.Parameters.AddWithValue("@d5", dtpEndDate.Text)
            cmd.Parameters.AddWithValue("@d6", txtAmtPaid.Text)
            'cmd.Parameters.AddWithValue("@d7", txtCPrice.Text)

            cmd.Parameters.AddWithValue("@d7", txtCNName.Text)
            'cmd.Parameters.AddWithValue("@d10", txtQtyName.Text)
            cmd.ExecuteReader()
            con.Close()

            Dim st As String = "updated the Gym '" & cmbDur.Text & "'details"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully updated", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub DeleteRecord()

        Try
            Dim RowsAffected As Integer = 0

            con = New SqlConnection(cs)
            con.Open()
            Dim cq As String = "delete from Gym where GymCName=@d8"
            cmd = New SqlCommand(cq)
            cmd.Parameters.AddWithValue("@d8", txtCNName.Text)
            'cmd.Parameters.AddWithValue("@d9", txtProdTypeName.Text)
            cmd.Connection = con
            RowsAffected = cmd.ExecuteNonQuery()
            If RowsAffected > 0 Then
                Dim st As String = "deleted the customer '" & txtCName.Text & "'"
                LogFunc(lblUser.Text, st)
                MessageBox.Show("Successfully deleted", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Getdata()
                Reset()
            Else
                MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                cmbDur.Text = dr.Cells(5).Value.ToString()
                dtpRegDate.Text = dr.Cells(2).Value.ToString()
                txtPNo.Text = dr.Cells(1).Value.ToString()
                dtpEndDate.Text = dr.Cells(3).Value.ToString()
                txtCName.Text = dr.Cells(0).Value.ToString()
                txtAmtPaid.Text = dr.Cells(4).Value.ToString()
                cmbRegType.Text = dr.Cells(6).Value.ToString()
                txtCNName.Text = dr.Cells(0).Value.ToString()
                btnUpdate.Enabled = True
                btnDelete.Enabled = True
                btnSave.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub
    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(GymCName), RTRIM(GPNo), RTRIM(RegDate), RTRIM(EndDate), RTRIM(AmtPaid), RTRIM(Duration), RTRIM(RegType) from Gym order by RegDate", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmGym_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
        'fillPost() 
        AcceptButton = btnSave
    End Sub

End Class