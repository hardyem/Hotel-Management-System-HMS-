﻿Imports System.Data.SqlClient

Public Class frmLogin
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If cmbUserType.Text = "" Then
            MessageBox.Show("Select User Type", "ADESH", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbUserType.Focus()
            Exit Sub
        End If
        If txtUser.Text = "" Then
            MessageBox.Show("Enter Username", "ADESH", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtUser.Focus()
            Exit Sub
        End If
        If txtPass.Text = "" Then
            MessageBox.Show("Enter Password", "ADESH", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPass.Focus()
            Exit Sub
        End If

        Try

            con = New SqlConnection(cs)
            con.Open()
            cmd = con.CreateCommand()
            cmd.CommandText = "SELECT Username,Password,UserType FROM Users where Username = @d1 and Password=@d2 and UserType=@d3"
            cmd.Parameters.AddWithValue("@d1", txtUser.Text)
            cmd.Parameters.AddWithValue("@d2", txtPass.Text)
            cmd.Parameters.AddWithValue("@d3", cmbUserType.Text)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                con = New SqlConnection(cs)
                con.Open()
                cmd = con.CreateCommand()
                cmd.CommandText = "SELECT UserType FROM Users where Username=@d3 and Password=@d4"
                cmd.Parameters.AddWithValue("@d3", txtUser.Text)
                cmd.Parameters.AddWithValue("@d4", txtPass.Text)
                rdr = cmd.ExecuteReader()

                'con.Close()
                ' Dim st As String = "Successfully logged in"

                '++++++++ CODE TO MAKE MAIN MENU SHOW USER TYPE, LIKE ADMIN, HARDYEM ETC

                If rdr.Read() Then
                    cmbUserType.Text = rdr.GetValue(0).ToString.Trim
                End If
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If

                frmMain.lblUser.Text = txtUser.Text
                frmMain.lblUserType.Text = cmbUserType.Text
                If frmMain.lblUserType.Text = "User" Then
                    frmMain.mDepartment.Visible = False
                    frmMain.mEmployee.Visible = False
                    frmMain.mPOS.Visible = True
                    frmMain.mTerminal.Visible = False
                    frmMain.mPosition.Visible = False
                    frmMain.mRoomType.Visible = False
                    frmMain.mRoomReg.Visible = False
                    frmMain.mDisc.Visible = False
                    frmMain.mAccDetail.Visible = False
                    frmMain.mPayroll.Visible = False
                    frmMain.mStaffRecord.Visible = False
                    frmMain.mPayRollRec.Visible = False
                    frmMain.mUsers.Visible = False
                    frmMain.mLogs.Visible = False
                ElseIf frmMain.lblUserType.Text = "Manager" Then
                    frmMain.mDepartment.Visible = True
                    frmMain.mEmployee.Visible = True
                    frmMain.mPOS.Visible = False
                    frmMain.mTerminal.Visible = True
                    frmMain.mPosition.Visible = True
                    frmMain.mRoomType.Visible = True
                    frmMain.mRoomReg.Visible = True
                    frmMain.mDisc.Visible = True
                    frmMain.mAccDetail.Visible = True
                    frmMain.mPayroll.Visible = True
                    frmMain.mStaffRecord.Visible = True
                    frmMain.mPayRollRec.Visible = True
                    frmMain.mUsers.Visible = False
                    frmMain.mLogs.Visible = False

                Else
                    frmMain.mDepartment.Visible = True
                    frmMain.mEmployee.Visible = True
                    frmMain.mPOS.Visible = True
                    frmMain.mTerminal.Visible = True
                    frmMain.mPosition.Visible = True
                    frmMain.mRoomType.Visible = True
                    frmMain.mRoomReg.Visible = True
                    frmMain.mDisc.Visible = True
                    frmMain.mAccDetail.Visible = True
                    frmMain.mPayroll.Visible = True
                    frmMain.mStaffRecord.Visible = True
                    frmMain.mPayRollRec.Visible = True
                    frmMain.mUsers.Visible = True
                    frmMain.mLogs.Visible = True
                End If

                Dim st As String = "Successfully logged in"
                LogFunc(txtUser.Text, st)
                MsgBox("Successfully logged in !", MsgBoxStyle.Information, "ACCESS GRANTED")
                con.Close()
                Me.Hide()
                frmMain.Show()

                '                     OR

                'I CAN JUST MAKE A COMBO BOX THAT HAS (admin,voters)
                ' then transfer the content with FRMMAIN.LBLUSER.TEXT=COMBOUSER.TEXT 
                'WITHOUT EVEN USING ANY USERTYPE FIELD IN THE DATABASE TABLE OF LOGIN
                '+++++++++++++ STOPPED HERE ++++++++++++++++++++++++

                'frmVoters.Show()

            Else
                MsgBox("Login Failed...Try again !", MsgBoxStyle.Critical, "ACCESS DENIED")
                txtUser.Text = ""
                txtPass.Text = ""
                txtUser.Focus()
            End If
            cmd.Dispose()
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Hide()
        frmChangePass.Show()
        frmChangePass.UserID.Text = ""
        frmChangePass.OldPassword.Text = ""
        frmChangePass.NewPassword.Text = ""
        frmChangePass.ConfirmPassword.Text = ""
        frmChangePass.UserID.Focus()
    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles Me.Load
        AcceptButton = btnLogin
        cmbUserType.Text = "User"
    End Sub
End Class