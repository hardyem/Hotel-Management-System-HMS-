﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUserType = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDateTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MetroTilePanel1 = New DevComponents.DotNetBar.Metro.MetroTilePanel()
        Me.ItemContainer1 = New DevComponents.DotNetBar.ItemContainer()
        Me.mEmployee = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mProduct = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mDepartment = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mGuest = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mTerminal = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mCheckIN = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mPOS = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mPosition = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mUsers = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mRoomType = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mGym = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.ItemContainer2 = New DevComponents.DotNetBar.ItemContainer()
        Me.mRoomReg = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mDisc = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mAccDetail = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mStockIn = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mPayroll = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mStockOut = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mCPass = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mLogs = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mLogOut = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.ItemContainer3 = New DevComponents.DotNetBar.ItemContainer()
        Me.mAvlStockRec = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mStockRec = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mAvlRoom = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mRoomRec = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mCINRec = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mStaffRecord = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.MetroTileItem7 = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.MetroTileItem8 = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mPayRollRec = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mPOSRecord = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.mExit = New DevComponents.DotNetBar.Metro.MetroTileItem()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer2
        '
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.lblUserType, Me.ToolStripStatusLabel2, Me.lblUser, Me.ToolStripStatusLabel3, Me.lblDateTime, Me.ToolStripStatusLabel4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 716)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1413, 33)
        Me.StatusStrip1.TabIndex = 6
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(112, 28)
        Me.ToolStripStatusLabel1.Text = "Logged in As:"
        '
        'lblUserType
        '
        Me.lblUserType.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserType.Image = Global.HMS.My.Resources.Resources.images1
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(106, 28)
        Me.lblUserType.Text = "User Type"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(14, 28)
        Me.ToolStripStatusLabel2.Text = ":"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(94, 28)
        Me.lblUser.Text = "User Name"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(963, 28)
        Me.ToolStripStatusLabel3.Spring = True
        '
        'lblDateTime
        '
        Me.lblDateTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(87, 28)
        Me.lblDateTime.Text = "Date Time"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(22, 28)
        Me.ToolStripStatusLabel4.Text = "a"
        '
        'MetroTilePanel1
        '
        '
        '
        '
        Me.MetroTilePanel1.BackgroundStyle.Class = "MetroTilePanel"
        Me.MetroTilePanel1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.MetroTilePanel1.ContainerControlProcessDialogKey = True
        Me.MetroTilePanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroTilePanel1.DragDropSupport = True
        Me.MetroTilePanel1.EnableDragDrop = True
        Me.MetroTilePanel1.Items.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.ItemContainer1, Me.ItemContainer2, Me.ItemContainer3})
        Me.MetroTilePanel1.LicenseKey = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F"
        Me.MetroTilePanel1.Location = New System.Drawing.Point(0, 0)
        Me.MetroTilePanel1.MultiLine = True
        Me.MetroTilePanel1.Name = "MetroTilePanel1"
        Me.MetroTilePanel1.Size = New System.Drawing.Size(1413, 716)
        Me.MetroTilePanel1.TabIndex = 7
        Me.MetroTilePanel1.Text = "MetroTilePanel1"
        '
        'ItemContainer1
        '
        '
        '
        '
        Me.ItemContainer1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.ItemContainer1.MultiLine = True
        Me.ItemContainer1.Name = "ItemContainer1"
        Me.ItemContainer1.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.mEmployee, Me.mProduct, Me.mDepartment, Me.mGuest, Me.mTerminal, Me.mCheckIN, Me.mPOS, Me.mPosition, Me.mUsers, Me.mRoomType, Me.mGym})
        '
        '
        '
        Me.ItemContainer1.TitleStyle.Class = "MetroTileGroupTitle"
        Me.ItemContainer1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.ItemContainer1.TitleText = "ADESH HOTEL & SUITES"
        '
        'mEmployee
        '
        Me.mEmployee.AutoRotateFramesInterval = 15
        Me.mEmployee.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mEmployee.Name = "mEmployee"
        Me.mEmployee.Symbol = ""
        Me.mEmployee.SymbolColor = System.Drawing.Color.Empty
        Me.mEmployee.SymbolSize = 45.0!
        Me.mEmployee.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Coffee
        Me.mEmployee.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mEmployee.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mEmployee.TitleText = "Employee"
        Me.mEmployee.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mEmployee.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mProduct
        '
        Me.mProduct.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mProduct.Name = "mProduct"
        Me.mProduct.Symbol = ""
        Me.mProduct.SymbolColor = System.Drawing.Color.Empty
        Me.mProduct.SymbolSize = 45.0!
        Me.mProduct.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Azure
        Me.mProduct.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mProduct.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mProduct.TitleText = "Product"
        Me.mProduct.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mProduct.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mDepartment
        '
        Me.mDepartment.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mDepartment.Name = "mDepartment"
        Me.mDepartment.Symbol = ""
        Me.mDepartment.SymbolColor = System.Drawing.Color.Empty
        Me.mDepartment.SymbolSize = 45.0!
        Me.mDepartment.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.[Default]
        Me.mDepartment.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mDepartment.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mDepartment.TitleText = "Department"
        Me.mDepartment.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mDepartment.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mGuest
        '
        Me.mGuest.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mGuest.Name = "mGuest"
        Me.mGuest.Symbol = ""
        Me.mGuest.SymbolColor = System.Drawing.Color.Empty
        Me.mGuest.SymbolSize = 45.0!
        Me.mGuest.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Magenta
        Me.mGuest.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mGuest.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mGuest.TitleText = "Guest"
        Me.mGuest.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mGuest.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mTerminal
        '
        Me.mTerminal.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mTerminal.Name = "mTerminal"
        Me.mTerminal.Symbol = ""
        Me.mTerminal.SymbolColor = System.Drawing.Color.Empty
        Me.mTerminal.SymbolSize = 45.0!
        Me.mTerminal.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Plum
        Me.mTerminal.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mTerminal.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mTerminal.TitleText = "Terminal"
        Me.mTerminal.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mTerminal.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mCheckIN
        '
        Me.mCheckIN.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mCheckIN.Name = "mCheckIN"
        Me.mCheckIN.Symbol = ""
        Me.mCheckIN.SymbolColor = System.Drawing.Color.Empty
        Me.mCheckIN.SymbolSize = 45.0!
        Me.mCheckIN.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Teal
        Me.mCheckIN.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mCheckIN.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mCheckIN.TitleText = "Check IN Panel"
        Me.mCheckIN.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mCheckIN.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mPOS
        '
        Me.mPOS.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mPOS.Name = "mPOS"
        Me.mPOS.Symbol = ""
        Me.mPOS.SymbolColor = System.Drawing.Color.Empty
        Me.mPOS.SymbolSize = 45.0!
        Me.mPOS.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Orange
        Me.mPOS.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mPOS.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mPOS.TitleText = "POS Panel"
        Me.mPOS.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mPOS.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mPosition
        '
        Me.mPosition.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mPosition.Name = "mPosition"
        Me.mPosition.Symbol = ""
        Me.mPosition.SymbolColor = System.Drawing.Color.Empty
        Me.mPosition.SymbolSize = 45.0!
        Me.mPosition.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Green
        Me.mPosition.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mPosition.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mPosition.TitleText = "Position"
        Me.mPosition.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mPosition.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mUsers
        '
        Me.mUsers.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mUsers.Name = "mUsers"
        Me.mUsers.Symbol = ""
        Me.mUsers.SymbolColor = System.Drawing.Color.Empty
        Me.mUsers.SymbolSize = 45.0!
        Me.mUsers.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Maroon
        Me.mUsers.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mUsers.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mUsers.TitleText = "Users Panel"
        Me.mUsers.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mUsers.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mRoomType
        '
        Me.mRoomType.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mRoomType.Name = "mRoomType"
        Me.mRoomType.Symbol = ""
        Me.mRoomType.SymbolColor = System.Drawing.Color.Empty
        Me.mRoomType.SymbolSize = 45.0!
        Me.mRoomType.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.RedViolet
        Me.mRoomType.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mRoomType.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mRoomType.TitleText = "Room Type"
        Me.mRoomType.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mRoomType.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mGym
        '
        Me.mGym.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mGym.Name = "mGym"
        Me.mGym.Symbol = ""
        Me.mGym.SymbolColor = System.Drawing.Color.Empty
        Me.mGym.SymbolSize = 45.0!
        Me.mGym.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Yellowish
        Me.mGym.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mGym.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mGym.TitleText = "Gym"
        Me.mGym.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mGym.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'ItemContainer2
        '
        '
        '
        '
        Me.ItemContainer2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.ItemContainer2.MultiLine = True
        Me.ItemContainer2.Name = "ItemContainer2"
        Me.ItemContainer2.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.mRoomReg, Me.mDisc, Me.mAccDetail, Me.mStockIn, Me.mPayroll, Me.mStockOut, Me.mCPass, Me.mLogs, Me.mLogOut})
        '
        '
        '
        Me.ItemContainer2.TitleStyle.Class = "MetroTileGroupTitle"
        Me.ItemContainer2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.ItemContainer2.TitleText = "Other Tools"
        '
        'mRoomReg
        '
        Me.mRoomReg.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mRoomReg.Name = "mRoomReg"
        Me.mRoomReg.Symbol = ""
        Me.mRoomReg.SymbolColor = System.Drawing.Color.Empty
        Me.mRoomReg.SymbolSize = 45.0!
        Me.mRoomReg.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Teal
        Me.mRoomReg.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mRoomReg.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mRoomReg.TitleText = "Room Registration"
        Me.mRoomReg.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mRoomReg.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mDisc
        '
        Me.mDisc.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mDisc.Name = "mDisc"
        Me.mDisc.Symbol = ""
        Me.mDisc.SymbolColor = System.Drawing.Color.Empty
        Me.mDisc.SymbolSize = 45.0!
        Me.mDisc.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Blueish
        Me.mDisc.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mDisc.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mDisc.TitleText = "Discount"
        Me.mDisc.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mDisc.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mAccDetail
        '
        Me.mAccDetail.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mAccDetail.Name = "mAccDetail"
        Me.mAccDetail.Symbol = ""
        Me.mAccDetail.SymbolColor = System.Drawing.Color.Empty
        Me.mAccDetail.SymbolSize = 45.0!
        Me.mAccDetail.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Maroon
        Me.mAccDetail.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mAccDetail.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mAccDetail.TitleText = "Account Details"
        Me.mAccDetail.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mAccDetail.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mStockIn
        '
        Me.mStockIn.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mStockIn.Name = "mStockIn"
        Me.mStockIn.Symbol = ""
        Me.mStockIn.SymbolColor = System.Drawing.Color.Empty
        Me.mStockIn.SymbolSize = 45.0!
        Me.mStockIn.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.MaroonWashed
        Me.mStockIn.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mStockIn.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mStockIn.TitleText = "Stock"
        Me.mStockIn.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mStockIn.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mPayroll
        '
        Me.mPayroll.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mPayroll.Name = "mPayroll"
        Me.mPayroll.Symbol = ""
        Me.mPayroll.SymbolColor = System.Drawing.Color.Empty
        Me.mPayroll.SymbolSize = 45.0!
        Me.mPayroll.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.DarkOlive
        Me.mPayroll.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mPayroll.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mPayroll.TitleText = "Pay Roll"
        Me.mPayroll.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mPayroll.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mStockOut
        '
        Me.mStockOut.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mStockOut.Name = "mStockOut"
        Me.mStockOut.Symbol = ""
        Me.mStockOut.SymbolColor = System.Drawing.Color.Empty
        Me.mStockOut.SymbolSize = 45.0!
        Me.mStockOut.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.PlumWashed
        Me.mStockOut.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mStockOut.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mStockOut.TitleText = "Stock Out"
        Me.mStockOut.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mStockOut.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mCPass
        '
        Me.mCPass.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mCPass.Name = "mCPass"
        Me.mCPass.Symbol = ""
        Me.mCPass.SymbolColor = System.Drawing.Color.Empty
        Me.mCPass.SymbolSize = 45.0!
        Me.mCPass.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Olive
        Me.mCPass.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mCPass.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mCPass.TitleText = "Change Password"
        Me.mCPass.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mCPass.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mLogs
        '
        Me.mLogs.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mLogs.Name = "mLogs"
        Me.mLogs.Symbol = ""
        Me.mLogs.SymbolColor = System.Drawing.Color.Empty
        Me.mLogs.SymbolSize = 45.0!
        Me.mLogs.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.[Default]
        Me.mLogs.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mLogs.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mLogs.TitleText = "Logs"
        Me.mLogs.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mLogs.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mLogOut
        '
        Me.mLogOut.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mLogOut.Name = "mLogOut"
        Me.mLogOut.Symbol = ""
        Me.mLogOut.SymbolColor = System.Drawing.Color.Empty
        Me.mLogOut.SymbolSize = 45.0!
        Me.mLogOut.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Azure
        Me.mLogOut.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mLogOut.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mLogOut.TitleText = "Log Out"
        Me.mLogOut.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mLogOut.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'ItemContainer3
        '
        '
        '
        '
        Me.ItemContainer3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.ItemContainer3.MultiLine = True
        Me.ItemContainer3.Name = "ItemContainer3"
        Me.ItemContainer3.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.mAvlStockRec, Me.mStockRec, Me.mAvlRoom, Me.mRoomRec, Me.mCINRec, Me.mStaffRecord, Me.MetroTileItem7, Me.MetroTileItem8, Me.mPayRollRec, Me.mPOSRecord, Me.mExit})
        '
        '
        '
        Me.ItemContainer3.TitleStyle.Class = "MetroTileGroupTitle"
        Me.ItemContainer3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.ItemContainer3.TitleText = "Records"
        '
        'mAvlStockRec
        '
        Me.mAvlStockRec.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mAvlStockRec.Name = "mAvlStockRec"
        Me.mAvlStockRec.Symbol = "57559"
        Me.mAvlStockRec.SymbolColor = System.Drawing.Color.Empty
        Me.mAvlStockRec.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mAvlStockRec.SymbolSize = 45.0!
        Me.mAvlStockRec.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Azure
        Me.mAvlStockRec.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mAvlStockRec.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mAvlStockRec.TitleText = "Available Stock Record"
        Me.mAvlStockRec.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mAvlStockRec.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mStockRec
        '
        Me.mStockRec.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mStockRec.Name = "mStockRec"
        Me.mStockRec.Symbol = "57685"
        Me.mStockRec.SymbolColor = System.Drawing.Color.Empty
        Me.mStockRec.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mStockRec.SymbolSize = 45.0!
        Me.mStockRec.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.PlumWashed
        Me.mStockRec.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mStockRec.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mStockRec.TitleText = "Stock Record"
        Me.mStockRec.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mStockRec.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mAvlRoom
        '
        Me.mAvlRoom.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mAvlRoom.Name = "mAvlRoom"
        Me.mAvlRoom.Symbol = "57698"
        Me.mAvlRoom.SymbolColor = System.Drawing.Color.Empty
        Me.mAvlRoom.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mAvlRoom.SymbolSize = 45.0!
        Me.mAvlRoom.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.MaroonWashed
        Me.mAvlRoom.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mAvlRoom.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mAvlRoom.TitleText = "Available Room"
        Me.mAvlRoom.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mAvlRoom.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mRoomRec
        '
        Me.mRoomRec.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mRoomRec.Name = "mRoomRec"
        Me.mRoomRec.Symbol = "57686"
        Me.mRoomRec.SymbolColor = System.Drawing.Color.Empty
        Me.mRoomRec.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mRoomRec.SymbolSize = 45.0!
        Me.mRoomRec.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.DarkGreen
        Me.mRoomRec.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mRoomRec.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mRoomRec.TitleText = "Room Record"
        Me.mRoomRec.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mRoomRec.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mCINRec
        '
        Me.mCINRec.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mCINRec.Name = "mCINRec"
        Me.mCINRec.Symbol = "57532"
        Me.mCINRec.SymbolColor = System.Drawing.Color.Empty
        Me.mCINRec.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mCINRec.SymbolSize = 45.0!
        Me.mCINRec.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Gray
        Me.mCINRec.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mCINRec.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mCINRec.TitleText = "Check IN Record"
        Me.mCINRec.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mCINRec.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mStaffRecord
        '
        Me.mStaffRecord.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mStaffRecord.Name = "mStaffRecord"
        Me.mStaffRecord.Symbol = "59387"
        Me.mStaffRecord.SymbolColor = System.Drawing.Color.Empty
        Me.mStaffRecord.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mStaffRecord.SymbolSize = 45.0!
        Me.mStaffRecord.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.DarkBlue
        Me.mStaffRecord.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mStaffRecord.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mStaffRecord.TitleText = "Employee Record"
        Me.mStaffRecord.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mStaffRecord.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'MetroTileItem7
        '
        Me.MetroTileItem7.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTileItem7.Name = "MetroTileItem7"
        Me.MetroTileItem7.Symbol = ""
        Me.MetroTileItem7.SymbolColor = System.Drawing.Color.Empty
        Me.MetroTileItem7.SymbolSize = 45.0!
        Me.MetroTileItem7.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Olive
        Me.MetroTileItem7.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.MetroTileItem7.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.MetroTileItem7.TitleText = "Change Password"
        Me.MetroTileItem7.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.MetroTileItem7.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroTileItem7.Visible = False
        '
        'MetroTileItem8
        '
        Me.MetroTileItem8.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTileItem8.Name = "MetroTileItem8"
        Me.MetroTileItem8.Symbol = ""
        Me.MetroTileItem8.SymbolColor = System.Drawing.Color.Empty
        Me.MetroTileItem8.SymbolSize = 45.0!
        Me.MetroTileItem8.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.[Default]
        Me.MetroTileItem8.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.MetroTileItem8.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.MetroTileItem8.TitleText = "Logs"
        Me.MetroTileItem8.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.MetroTileItem8.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroTileItem8.Visible = False
        '
        'mPayRollRec
        '
        Me.mPayRollRec.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mPayRollRec.Name = "mPayRollRec"
        Me.mPayRollRec.Symbol = "59614"
        Me.mPayRollRec.SymbolColor = System.Drawing.Color.Empty
        Me.mPayRollRec.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mPayRollRec.SymbolSize = 45.0!
        Me.mPayRollRec.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Blueish
        Me.mPayRollRec.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mPayRollRec.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mPayRollRec.TitleText = "Payroll Record"
        Me.mPayRollRec.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mPayRollRec.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mPOSRecord
        '
        Me.mPOSRecord.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mPOSRecord.Name = "mPOSRecord"
        Me.mPOSRecord.Symbol = "59596"
        Me.mPOSRecord.SymbolColor = System.Drawing.Color.Empty
        Me.mPOSRecord.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material
        Me.mPOSRecord.SymbolSize = 45.0!
        Me.mPOSRecord.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Yellowish
        Me.mPOSRecord.TileSize = New System.Drawing.Size(270, 180)
        '
        '
        '
        Me.mPOSRecord.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mPOSRecord.TitleText = "POS Record"
        Me.mPOSRecord.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mPOSRecord.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'mExit
        '
        Me.mExit.ImageTextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.mExit.Name = "mExit"
        Me.mExit.Symbol = ""
        Me.mExit.SymbolColor = System.Drawing.Color.Empty
        Me.mExit.SymbolSize = 45.0!
        Me.mExit.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.RedViolet
        Me.mExit.TileSize = New System.Drawing.Size(180, 180)
        '
        '
        '
        Me.mExit.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square
        Me.mExit.TitleText = "Exit App"
        Me.mExit.TitleTextAlignment = System.Drawing.ContentAlignment.BottomCenter
        Me.mExit.TitleTextFont = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1413, 749)
        Me.Controls.Add(Me.MetroTilePanel1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HOTEL MANAGEMENT SYSTEM V1.0"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer1 As Timer
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents lblUserType As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents lblUser As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents lblDateTime As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents MetroTilePanel1 As DevComponents.DotNetBar.Metro.MetroTilePanel
    Friend WithEvents ItemContainer1 As DevComponents.DotNetBar.ItemContainer
    Friend WithEvents mEmployee As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mProduct As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mDepartment As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mGuest As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mTerminal As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mCheckIN As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mPOS As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mPosition As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mRoomType As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mGym As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mUsers As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents ItemContainer2 As DevComponents.DotNetBar.ItemContainer
    Friend WithEvents mRoomReg As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mDisc As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mLogOut As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mPayroll As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mStockIn As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mStockOut As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mAccDetail As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mCPass As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mLogs As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents Timer3 As Timer
    Friend WithEvents mPOSRecord As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents ItemContainer3 As DevComponents.DotNetBar.ItemContainer
    Friend WithEvents mAvlStockRec As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mStockRec As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mAvlRoom As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mRoomRec As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mCINRec As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mStaffRecord As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents MetroTileItem7 As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents MetroTileItem8 As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mExit As DevComponents.DotNetBar.Metro.MetroTileItem
    Friend WithEvents mPayRollRec As DevComponents.DotNetBar.Metro.MetroTileItem
End Class
