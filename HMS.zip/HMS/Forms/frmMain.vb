﻿Public Class frmMain
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblDateTime.Text = Now.ToString("dd/MM/yyyy hh:mm:ss tt")
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Cursor = Cursors.Default
        Timer2.Enabled = False
    End Sub

    Private Sub MLogOut_Click(sender As Object, e As EventArgs) Handles mLogOut.Click
        Try
            If MessageBox.Show("Do you really want to logout from application?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Me.Hide()
                frmLogin.Show()
                frmLogin.txtUser.Text = ""
                frmLogin.txtPass.Text = ""
                frmLogin.txtUser.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub MProduct_Click(sender As Object, e As EventArgs) Handles mProduct.Click
        frmProduct.lblUser.Text = lblUser.Text
        frmProduct.Reset()
        frmProduct.ShowDialog()
    End Sub

    Private Sub MDepartment_Click(sender As Object, e As EventArgs) Handles mDepartment.Click
        frmDepartment.lblUser.Text = lblUser.Text
        frmDepartment.Reset()
        frmDepartment.ShowDialog()
    End Sub

    Private Sub MGuest_Click(sender As Object, e As EventArgs) Handles mGuest.Click
        frmGuest.lblUser.Text = lblUser.Text
        frmGuest.Reset()
        frmGuest.ShowDialog()
    End Sub

    Private Sub MTerminal_Click(sender As Object, e As EventArgs) Handles mTerminal.Click
        frmTerminal.lblUser.Text = lblUser.Text
        frmTerminal.Reset()
        frmTerminal.ShowDialog()
    End Sub

    Private Sub MUsers_Click(sender As Object, e As EventArgs) Handles mUsers.Click
        frmNewUser.lblUser.Text = lblUser.Text
        frmNewUser.Reset()
        frmNewUser.ShowDialog()
    End Sub

    Private Sub MPOS_Click(sender As Object, e As EventArgs) Handles mPOS.Click
        frmPosTransact.lblUser.Text = lblUser.Text
        frmPosTransact.Reset()
        frmPosTransact.ShowDialog()
    End Sub

    Private Sub MPosition_Click(sender As Object, e As EventArgs) Handles mPosition.Click
        frmPosition.lblUser.Text = lblUser.Text
        frmPosition.Reset()
        frmPosition.ShowDialog()
    End Sub

    Private Sub MRoomType_Click(sender As Object, e As EventArgs) Handles mRoomType.Click
        frmRoomType.lblUser.Text = lblUser.Text
        frmRoomType.Reset()
        frmRoomType.ShowDialog()
    End Sub

    Private Sub MLogs_Click(sender As Object, e As EventArgs) Handles mLogs.Click
        frmLogs.lblUser.Text = lblUser.Text
        frmLogs.Reset()
        frmLogs.ShowDialog()
    End Sub

    Private Sub MCPass_Click(sender As Object, e As EventArgs) Handles mCPass.Click
        frmChangePass.lblUser.Text = lblUser.Text
        frmChangePass.Reset()
        frmChangePass.ShowDialog()
    End Sub

    Private Sub MRoomReg_Click(sender As Object, e As EventArgs) Handles mRoomReg.Click
        frmRoomReg.lblUser.Text = lblUser.Text
        frmRoomReg.Reset()
        frmRoomReg.ShowDialog()
    End Sub

    Private Sub MDisc_Click(sender As Object, e As EventArgs) Handles mDisc.Click
        frmDiscount.lblUser.Text = lblUser.Text
        frmDiscount.Reset()
        frmDiscount.ShowDialog()
    End Sub

    Private Sub MAccDetail_Click(sender As Object, e As EventArgs) Handles mAccDetail.Click
        frmAccDetails.lblUser.Text = lblUser.Text
        frmAccDetails.Reset()
        frmAccDetails.ShowDialog()
    End Sub

    Private Sub MStockIn_Click(sender As Object, e As EventArgs) Handles mStockIn.Click
        frmStockIn.lblUser.Text = lblUser.Text
        frmStockIn.Reset()
        frmStockIn.ShowDialog()
    End Sub

    Private Sub MPayroll_Click(sender As Object, e As EventArgs) Handles mPayroll.Click
        frmPayroll.lblUser.Text = lblUser.Text
        frmPayroll.Reset()
        frmPayroll.ShowDialog()
    End Sub

    Private Sub MStockOut_Click(sender As Object, e As EventArgs) Handles mStockOut.Click
        frmStockOut.lblUser.Text = lblUser.Text
        frmStockOut.Reset()
        frmStockOut.ShowDialog()
    End Sub

    Private Sub MPOSRecord_Click(sender As Object, e As EventArgs) Handles mPOSRecord.Click
        frmPOSRecord.lblUser.Text = lblUser.Text
        frmPOSRecord.Reset()
        frmPOSRecord.ShowDialog()
    End Sub

    Private Sub MAvlStockRec_Click(sender As Object, e As EventArgs) Handles mAvlStockRec.Click
        frmStockInRecord.lblUser.Text = lblUser.Text
        frmStockInRecord.Reset()
        frmStockInRecord.ShowDialog()
    End Sub

    Private Sub MStockRec_Click(sender As Object, e As EventArgs) Handles mStockRec.Click
        frmStockRecord.lblUser.Text = lblUser.Text
        frmStockRecord.Reset()
        frmStockRecord.ShowDialog()
    End Sub

    Private Sub MCheckIN_Click(sender As Object, e As EventArgs) Handles mCheckIN.Click
        frmCheckIn.lblUser.Text = lblUser.Text
        frmCheckIn.Reset()
        frmCheckIn.ShowDialog()
    End Sub

    Private Sub MAvlRoom_Click(sender As Object, e As EventArgs) Handles mAvlRoom.Click
        frmAvlRoomRec.lblUser.Text = lblUser.Text
        frmAvlRoomRec.Reset()
        frmAvlRoomRec.ShowDialog()
    End Sub

    Private Sub MRoomRec_Click(sender As Object, e As EventArgs) Handles mRoomRec.Click
        frmRoomRec.lblUser.Text = lblUser.Text
        frmRoomRec.Reset()
        frmRoomRec.ShowDialog()
    End Sub

    Private Sub MCINRec_Click(sender As Object, e As EventArgs) Handles mCINRec.Click
        frmCheckINRec.lblUser.Text = lblUser.Text
        frmCheckINRec.Reset()
        frmCheckINRec.ShowDialog()
    End Sub

    Private Sub MEmployee_Click(sender As Object, e As EventArgs) Handles mEmployee.Click
        frmStaff.lblUser.Text = lblUser.Text
        frmStaff.Reset()
        frmStaff.ShowDialog()
    End Sub

    Private Sub MStaffRecord_Click(sender As Object, e As EventArgs) Handles mStaffRecord.Click
        frmStaffRecord.lblUser.Text = lblUser.Text
        frmStaffRecord.Reset()
        frmStaffRecord.ShowDialog()
    End Sub

    Private Sub MGym_Click(sender As Object, e As EventArgs) Handles mGym.Click
        frmGymReg.lblUser.Text = lblUser.Text
        frmGymReg.Reset()
        frmGymReg.ShowDialog()
    End Sub

    Private Sub MPayRollRec_Click(sender As Object, e As EventArgs) Handles mPayRollRec.Click
        frmPayRollRec.lblUser.Text = lblUser.Text
        frmPayRollRec.Reset()
        frmPayRollRec.ShowDialog()
    End Sub

    Private Sub MExit_Click(sender As Object, e As EventArgs) Handles mExit.Click
        End
    End Sub
End Class