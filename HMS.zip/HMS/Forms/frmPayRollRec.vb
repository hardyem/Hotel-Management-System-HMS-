﻿Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.IO

Public Class frmPayRollRec

    Sub fillDept()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(Dept) FROM Department", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbDept.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbDept.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID), RTRIM(EmpFName), RTRIM(Salary), RTRIM(Dept), RTRIM(Bal), RTRIM(Deduction), RTRIM(Arrears), RTRIM(Year), RTRIM(Month) from PayRoll order by [StaffID]", con)
            'cmd = New SqlCommand("SELECT RTRIM(posid), RTRIM(Stan), RTRIM(dept), RTRIM(acode), RTRIM(terminal), RTRIM(amt), RTRIM(AuthorBy), RTRIM(Ttime), RTRIM(tdate), RTRIM(cno), RTRIM(CType) from POStransact order by [TDate]", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub frmSalesRecord_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Getdata()
        fillDept()
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub
    Sub Reset()
        TextBox2.Text = ""
        'cmbCashName.Text = ""
        cmbMonth.SelectedIndex = -1
        cmbYear.SelectedIndex = -1
        cmbDept.SelectedIndex = -1
        'dtpDateFrom.Text = Today
        'dtpDateTo.Text = Today
        lblSet.Text = ""
        Getdata()
    End Sub

    Private Sub btnReset_Click(sender As System.Object, e As System.EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnExportExcel_Click(sender As System.Object, e As System.EventArgs) Handles btnExportExcel.Click
        'ExportExcel(dgw)
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application
        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgw.RowCount
            colsTotal = dgw.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgw.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgw.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID), RTRIM(EmpFName), RTRIM(Salary), RTRIM(Dept), RTRIM(Bal), RTRIM(Deduction), RTRIM(Arrears), RTRIM(Year), RTRIM(Month) from PayRoll where [EmpFName] like '%" & TextBox2.Text & "%' order by [StaffID]", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8))
            End While
            con.Close()

            Dim sum As Int64 = 0
            'Try
            For Each r As DataGridViewRow In Me.dgw.Rows
                sum = sum + r.Cells(4).Value
            Next
            txtTotAmt.Text = sum
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub cmbDept_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbDept.SelectedIndexChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID), RTRIM(EmpFName), RTRIM(Salary), RTRIM(Dept), RTRIM(Bal), RTRIM(Deduction), RTRIM(Arrears), RTRIM(Year), RTRIM(Month) from PayRoll where [Dept] like '%" & cmbDept.Text & "%' order by [StaffID]", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8))
            End While
            con.Close()

            Dim sum As Int64 = 0
            'Try
            For Each r As DataGridViewRow In Me.dgw.Rows
                sum = sum + r.Cells(4).Value
            Next
            txtTotAmt.Text = sum
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If cmbMonth.Text = "" Or cmbYear.Text = "" Then
            MessageBox.Show("Please select Month and Year", "ADESH", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        Else
            Try
                con = New SqlConnection(cs)
                con.Open()
                cmd = New SqlCommand("SELECT RTRIM(StaffID), RTRIM(EmpFName), RTRIM(Salary), RTRIM(Dept), RTRIM(Bal), RTRIM(Deduction), RTRIM(Arrears), RTRIM(Year), RTRIM(Month) from PayRoll where [Month] = '" & cmbMonth.Text & "' and [Year] = '" & cmbYear.Text & "' order by [StaffID]", con)
                rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgw.Rows.Clear()
                While (rdr.Read() = True)
                    dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8))
                End While
                con.Close()

                Dim sum As Int64 = 0
                'Try
                For Each r As DataGridViewRow In Me.dgw.Rows
                    sum = sum + r.Cells(4).Value
                Next
                txtTotAmt.Text = sum
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

    End Sub
End Class
