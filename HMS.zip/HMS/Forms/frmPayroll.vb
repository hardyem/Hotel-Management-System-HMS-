﻿Imports System.Data.SqlClient

Public Class frmPayroll
    Sub Reset()

        lblSID.Text = ""
        lblSAmt.Text = ""
        lblAHN.Text = ""
        cmbDept.Text = ""
        cmbMonth.Text = ""
        cmbWHour.Text = ""
        cmbYear.Text = ""
        txtArr.Text = ""
        txtBal.Text = ""
        txtDed.Text = ""
        'cmbProdType.SelectedIndex = -1
        dtpPayDate.Text = Today
        txtRem.Text = ""
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        cmbDept.Focus()
    End Sub

    Sub fillDept()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(Dept) FROM Department", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbDept.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbDept.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If lblAHN.Text = "" Then
            MessageBox.Show("Load account holder name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblAHN.Focus()
            Return
        End If
        If lblSID.Text = "" Then
            MessageBox.Show("Load staff ID", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblSID.Focus()
            Return
        End If
        If cmbYear.Text = "" Then
            MessageBox.Show("Please select payment year", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbYear.Focus()
            Return
        End If
        If cmbMonth.Text = "" Then
            MessageBox.Show("Please select payment month", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbMonth.Focus()
            Return
        End If
        If dtpPayDate.Text = "" Then
            MessageBox.Show("Please select registration date", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            dtpPayDate.Focus()
            Return
        End If
        Try
            con = New SqlConnection(cs)
            con.Open()
            Dim ct As String = "select StaffID from PayRoll where StaffID=@d1 and Year=@d2 and Month=@d3"
            cmd = New SqlCommand(ct)
            cmd.Parameters.AddWithValue("@d1", lblSID.Text)
            cmd.Parameters.AddWithValue("@d2", cmbYear.Text)
            cmd.Parameters.AddWithValue("@d3", cmbMonth.Text)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                MessageBox.Show("Salary is already processed", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                'lblsamt.Text = ""
                'lblsamt.Focus()
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                Return
            End If

            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "insert into PayRoll(EmpFName, Salary, StaffID, Dept, WorkHour, Year, Month, PayDate, Deduction, Arrears, Bal,Rem) VALUES (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12)"
            cmd = New SqlCommand(cb)
            cmd.Parameters.AddWithValue("@d1", lblAHN.Text)
            cmd.Parameters.AddWithValue("@d2", lblSAmt.Text)
            cmd.Parameters.AddWithValue("@d3", lblSID.Text)
            cmd.Parameters.AddWithValue("@d4", cmbDept.Text)
            cmd.Parameters.AddWithValue("@d5", cmbWHour.Text)
            cmd.Parameters.AddWithValue("@d6", cmbYear.Text)
            cmd.Parameters.AddWithValue("@d7", cmbMonth.Text)
            cmd.Parameters.AddWithValue("@d8", dtpPayDate.Value.Date)
            cmd.Parameters.AddWithValue("@d9", txtDed.Text)
            cmd.Parameters.AddWithValue("@d10", txtArr.Text)
            cmd.Parameters.AddWithValue("@d11", txtBal.Text)
            cmd.Parameters.AddWithValue("@d12", txtRem.Text)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()
            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            con = New SqlConnection(cs)
            con.Open()

            Dim st As String = "Salary processed for '" & lblAHN.Text & "'"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully Saved", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSave.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If lblAHN.Text = "" Then
            MessageBox.Show("Load account holder name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblAHN.Focus()
            Return
        End If
        If lblSID.Text = "" Then
            MessageBox.Show("Load staff ID", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lblSID.Focus()
            Return
        End If
        If cmbYear.Text = "" Then
            MessageBox.Show("Please select payment year", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbYear.Focus()
            Return
        End If
        If cmbMonth.Text = "" Then
            MessageBox.Show("Please select payment month", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbMonth.Focus()
            Return
        End If
        If dtpPayDate.Text = "" Then
            MessageBox.Show("Please select registration in date", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            dtpPayDate.Focus()
            Return
        End If

        Try
            con = New SqlConnection(cs)
            con.Open()
            Dim ct As String = "select StaffID from PayRoll where StaffID=@d1 and Year=@d2 and Month=@d3"
            cmd = New SqlCommand(ct)
            cmd.Parameters.AddWithValue("@d1", lblSID.Text)
            cmd.Parameters.AddWithValue("@d2", cmbYear.Text)
            cmd.Parameters.AddWithValue("@d3", cmbMonth.Text)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                MessageBox.Show("Salary is already processed", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                'lblsamt.Text = ""
                'lblsamt.Focus()
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                Return
            End If

            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "Update PayRoll set EmpFName=@d1, Salary=@d2, StaffID=@d3, Dept=@d4, WorkHour=@d5, Year=@d6, Month=@d7, PayDate=@d8, Deduction=@d9, Arrears=@d10, Bal=@d11, Rem=@d12 where StaffID=@d13 and Year=@d14 and Month=@d15"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", lblAHN.Text)
            cmd.Parameters.AddWithValue("@d2", lblSAmt.Text)
            cmd.Parameters.AddWithValue("@d3", lblSID.Text)
            cmd.Parameters.AddWithValue("@d4", cmbDept.Text)
            cmd.Parameters.AddWithValue("@d5", cmbWHour.Text)
            cmd.Parameters.AddWithValue("@d6", cmbYear.Text)
            cmd.Parameters.AddWithValue("@d7", cmbMonth.Text)
            cmd.Parameters.AddWithValue("@d8", dtpPayDate.Value.Date)
            cmd.Parameters.AddWithValue("@d9", txtDed.Text)
            cmd.Parameters.AddWithValue("@d10", txtArr.Text)
            cmd.Parameters.AddWithValue("@d11", txtBal.Text)
            cmd.Parameters.AddWithValue("@d12", txtRem.Text)

            cmd.Parameters.AddWithValue("@d13", txtSIDName.Text)
            cmd.Parameters.AddWithValue("@d14", txtY.Text)
            cmd.Parameters.AddWithValue("@d15", txtM.Text)
            cmd.ExecuteReader()
            con.Close()

            Dim st As String = "updated the payroll for '" & lblSID.Text & "' details"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully updated", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub DeleteRecord()

        Try
            Dim RowsAffected As Integer = 0

            con = New SqlConnection(cs)
            con.Open()
            Dim cq As String = "delete from PayRoll where StaffID=@d1 and Year=@d2 and Month=@d3"
            cmd = New SqlCommand(cq)
            cmd.Parameters.AddWithValue("@d1", txtSIDName.Text)
            cmd.Parameters.AddWithValue("@d2", txtY.Text)
            cmd.Parameters.AddWithValue("@d3", txtM.Text)
            cmd.Connection = con
            RowsAffected = cmd.ExecuteNonQuery()
            If RowsAffected > 0 Then
                Dim st As String = "Successfully deleted payroll for '" & lblSID.Text & "'"
                LogFunc(lblUser.Text, st)
                MessageBox.Show("Successfully deleted payroll", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Getdata()
                Reset()
            Else
                MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                lblAHN.Text = dr.Cells(1).Value.ToString()
                lblSAmt.Text = dr.Cells(2).Value.ToString()
                cmbYear.Text = dr.Cells(6).Value.ToString()
                txtY.Text = dr.Cells(6).Value.ToString()
                cmbMonth.Text = dr.Cells(7).Value.ToString()
                txtM.Text = dr.Cells(7).Value.ToString()
                cmbDept.Text = dr.Cells(3).Value.ToString()
                '++++++++++++++++++++++++++++++++++++++++++++++++
                lblSID.Text = dr.Cells(0).Value.ToString()
                txtDed.Text = dr.Cells(8).Value.ToString()
                cmbWHour.Text = dr.Cells(5).Value.ToString()
                dtpPayDate.Text = dr.Cells(10).Value.ToString()
                txtArr.Text = dr.Cells(9).Value.ToString()
                '++++++++++++++++++++++++++++++++++++++++++++++++
                txtSIDName.Text = dr.Cells(0).Value.ToString()
                txtBal.Text = dr.Cells(4).Value.ToString()
                txtRem.Text = dr.Cells(11).Value.ToString()
                btnUpdate.Enabled = True
                btnDelete.Enabled = True
                btnSave.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID), RTRIM(EmpFName), RTRIM(Salary), RTRIM(Dept), RTRIM(Bal), RTRIM(WorkHour), RTRIM(Year), RTRIM(Month), RTRIM(Deduction), RTRIM(Arrears), RTRIM(PayDate), RTRIM(Rem) from PayRoll order by StaffID", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmPayRoll_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
        AcceptButton = btnSave
        fillDept()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Me.Reset()
        frmAccDetails.lblSet.Text = "Payroll"
        frmAccDetails.Reset()
        frmAccDetails.ShowDialog()
    End Sub

    Private Sub TxtBal_TextChanged(sender As Object, e As EventArgs) Handles txtBal.TextChanged
        txtBal.Text = Val(lblSAmt.Text) + Val(txtArr.Text) - Val(txtDed.Text)
    End Sub

    Private Sub txtBal_Click(sender As Object, e As EventArgs) Handles txtBal.Click
        txtBal.Text = Val(lblSAmt.Text) + Val(txtArr.Text) - Val(txtDed.Text)
    End Sub

    Private Sub TxtArr_TextChanged(sender As Object, e As EventArgs) Handles txtArr.TextChanged
        txtBal.Text = Val(lblSAmt.Text) + Val(txtArr.Text) - Val(txtDed.Text)
    End Sub

    Private Sub TxtDed_TextChanged(sender As Object, e As EventArgs) Handles txtDed.TextChanged
        txtBal.Text = Val(lblSAmt.Text) + Val(txtArr.Text) - Val(txtDed.Text)
    End Sub

    Private Sub CmbYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbYear.SelectedIndexChanged
        txtBal.Text = Val(lblSAmt.Text) + Val(txtArr.Text) - Val(txtDed.Text)
    End Sub

    Private Sub CmbMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMonth.SelectedIndexChanged
        txtBal.Text = Val(lblSAmt.Text) + Val(txtArr.Text) - Val(txtDed.Text)
    End Sub
End Class