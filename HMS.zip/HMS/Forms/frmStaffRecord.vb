﻿Imports System.Data.SqlClient
Imports System.IO
Public Class frmStaffRecord
    Sub Reset()
        cmbDept.Text = ""
        txtNName.Text = ""
        GetData()
    End Sub
    Private Sub btnReset_Click(sender As System.Object, e As System.EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Sub fillDept()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(Dept) FROM Department", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbDept.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbDept.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub GetData()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID) as [Staff ID], RTRIM(EFName) as [Staff Name], RTRIM(PNo) as [Phone No.], RTRIM(Dept) as [Department], RTRIM(Sex) as [Gender], RTRIM(Address) as [Address], RTRIM(State) as [State], RTRIM(LGA) as [LGA], RTRIM(EMail) as [E-Mail], RTRIM(DOB) as [Date of Birth], RTRIM(Religion) as [Religion], RTRIM(Qualification) as [Qualification], RTRIM(SGName) as [Guarantor Name], RTRIM(SGPNo) as [Phone No], RTRIM(SNKName) as [Next-of-Kin Name], RTRIM(SNKNo) as [Phone No], Photo from Staff order by Dept, EFName", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Staff")
            dgw.DataSource = ds.Tables("Staff").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub txtNName_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtNName.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID) as [Staff ID], RTRIM(EFName) as [Staff Name], RTRIM(PNo) as [Phone No.], RTRIM(Dept) as [Department], RTRIM(Sex) as [Gender], RTRIM(Address) as [Address], RTRIM(State) as [State], RTRIM(LGA) as [LGA], RTRIM(EMail) as [E-Mail], RTRIM(DOB) as [Date of Birth], RTRIM(Religion) as [Religion], RTRIM(Qualification) as [Qualification], RTRIM(SGName) as [Guarantor Name], RTRIM(SGPNo) as [Phone No], RTRIM(SNKName) as [Next-of-Kin Name], RTRIM(SNKNo) as [Phone No], Photo from Staff where EFName like '%" & txtNName.Text & "%' order by Dept, EFName", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Staff")
            dgw.DataSource = ds.Tables("Staff").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmStaffRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillDept()
        GetData()
    End Sub

    Private Sub CmbPost_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbDept.SelectedIndexChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StaffID) as [Staff ID], RTRIM(EFName) as [Staff Name], RTRIM(PNo) as [Phone No.], RTRIM(Dept) as [Department], RTRIM(Sex) as [Gender], RTRIM(Address) as [Address], RTRIM(State) as [State], RTRIM(LGA) as [LGA], RTRIM(EMail) as [E-Mail], RTRIM(DOB) as [Date of Birth], RTRIM(Religion) as [Religion], RTRIM(Qualification) as [Qualification], RTRIM(SGName) as [Guarantor Name], RTRIM(SGPNo) as [Phone No], RTRIM(SNKName) as [Next-of-Kin Name], RTRIM(SNKNo) as [Phone No], Photo from Staff where Dept='" & cmbDept.Text & "' order by Dept, EFName", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Staff")
            dgw.DataSource = ds.Tables("Staff").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_MouseClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                If lblSet.Text = "Staff Entry" Then
                    Me.Hide()
                    frmStaff.Show()
                    frmStaff.txtEFN.Text = dr.Cells(1).Value.ToString()
                    frmStaff.lblSID.Text = dr.Cells(0).Value.ToString()
                    frmStaff.txtSIDName.Text = dr.Cells(0).Value.ToString()
                    frmStaff.cmbQual.Text = dr.Cells(11).Value.ToString()
                    frmStaff.txtState.Text = dr.Cells(6).Value.ToString()
                    frmStaff.txtLGA.Text = dr.Cells(7).Value.ToString()
                    frmStaff.txtGFN.Text = dr.Cells(12).Value.ToString()
                    frmStaff.cmbSex.Text = dr.Cells(4).Value.ToString()
                    frmStaff.txtGPNo.Text = dr.Cells(13).Value.ToString()
                    frmStaff.txtNFN.Text = dr.Cells(14).Value.ToString()
                    frmStaff.cmbDept.Text = dr.Cells(3).Value.ToString()
                    frmStaff.txtNPNo.Text = dr.Cells(15).Value.ToString()
                    frmStaff.txtPNo.Text = dr.Cells(2).Value.ToString()
                    frmStaff.txtEMail.Text = dr.Cells(8).Value.ToString()
                    frmStaff.txtAddress.Text = dr.Cells(5).Value.ToString()
                    frmStaff.cmbReligion.Text = dr.Cells(10).Value.ToString()
                    frmStaff.dtpDOB.Text = dr.Cells(9).Value.ToString()
                    Dim data As Byte() = DirectCast(dr.Cells(16).Value, Byte())
                    Dim ms As New MemoryStream(data)
                    frmStaff.Picture.Image = Image.FromStream(ms)

                    frmStaff.btnDelete.Enabled = True
                    frmStaff.btnUpdate.Enabled = True
                    frmStaff.btnSave.Enabled = False
                    frmStaff.btnGen.Enabled = False

                    If (rdr IsNot Nothing) Then
                        rdr.Close()
                    End If
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    lblSet.Text = ""
                ElseIf lblSet.Text = "Staff" Then
                    Me.Hide()
                    frmStaff.Show()
                    frmAccDetails.lblEFN.Text = dr.Cells(1).Value.ToString()
                    frmAccDetails.lblSID.Text = dr.Cells(0).Value.ToString()
                    'Dim data As Byte() = DirectCast(dr.Cells(16).Value, Byte())
                    'Dim ms As New MemoryStream(data)
                    'frmStaff.Picture.Image = Image.FromStream(ms)
                    frmStaff.btnDelete.Enabled = False
                    frmStaff.btnUpdate.Enabled = False
                    frmStaff.btnSave.Enabled = True

                    If (rdr IsNot Nothing) Then
                        rdr.Close()
                    End If
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    lblSet.Text = ""
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(sender As Object, e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub

    Private Sub Dgw_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgw.CellContentClick

    End Sub
End Class