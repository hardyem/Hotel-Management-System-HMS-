﻿Imports System.Data.SqlClient
Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmStockRecord

    Sub Reset()
        TextBox2.Text = ""
        Getdata()
    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(ProdName) as [Product Name], RTRIM(CostPrice) as [Cost Price], RTRIM(Qty) as [Quantity], RTRIM(StockDate) as [Stock Date], RTRIM(RepIC) as [Rep-In-Charge] FROM  StockIN order by StockDate, ProdName, Qty", con)
            Dim myDA As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "StockIN")
            dgw.DataSource = myDataSet.Tables("StockIN").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub frmStockRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(ProdName) as [Product Name], RTRIM(CostPrice) as [Cost Price], RTRIM(Qty) as [Quantity], RTRIM(StockDate) as [Stock Date], RTRIM(RepIC) as [Rep-In-Charge] FROM  StockIN where ProdName like '%" & TextBox2.Text & "%' order by StockDate, ProdName, Qty", con)
            'cmd = New SqlCommand("SELECT RTRIM(Temp_Stock.ProdName) as [Product Name], RTRIM(Temp_Stock.ProdType) as [Product Type], RTRIM(UnitPrice) as [UnitPrice], RTRIM(BulkPrice) as [Bulk Price], RTRIM(Temp_Stock.Qty) as [Avl. Qty.], RTRIM(ExpDate) as [Expiry Date] FROM Temp_Stock INNER JOIN Products ON Temp_Stock.ProdName=Products.ProdName and Temp_Stock.ProdType=Products.Type where ProdName like '%" & TextBox2.Text & "%' order by Temp_Stock.ProdName, ProdType", con)
            Dim myDA As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "StockIN")
            dgw.DataSource = myDataSet.Tables("StockIN").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub btnExportExcel_Click(sender As Object, e As EventArgs) Handles btnExportExcel.Click
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application
        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgw.RowCount
            colsTotal = dgw.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgw.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgw.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub

    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(ProdName) as [Product Name], RTRIM(CostPrice) as [Cost Price], RTRIM(Qty) as [Quantity], RTRIM(StockDate) as [Stock Date], RTRIM(RepIC) as [Rep-In-Charge] FROM  StockIN where StockDate between @d1 and @d2 order by StockDate, ProdName, Qty", con)
            cmd.Parameters.Add("@d1", SqlDbType.DateTime, 30, "StockDate").Value = dtpDateFrom.Value.Date
            cmd.Parameters.Add("@d2", SqlDbType.DateTime, 30, "StockDate").Value = dtpDateTo.Value.Date
            Dim myDA As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "StockIN")
            dgw.DataSource = myDataSet.Tables("StockIN").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            ' Dim rpt As New rptStock() 'The report you created.
            Dim myConnection As SqlConnection
            Dim MyCommand, MyCommand1 As New SqlCommand()
            Dim myDA, myDA1 As New SqlDataAdapter()
            Dim myDS As New DataSet 'The DataSet you created.
            myConnection = New SqlConnection(cs)
            MyCommand.Connection = myConnection
            MyCommand1.Connection = myConnection
            MyCommand.CommandText = "Select * from StockIN where ProdName Like '%" & TextBox2.Text & "%' order by StockDate, ProdName, Qty"
            MyCommand.CommandType = CommandType.Text
            myDA.SelectCommand = MyCommand
            myDA.Fill(myDS, "StockIN")
            ' rpt.SetDataSource(myDS)
            'rpt.SetParameterValue("@d1", dtpDateFrom.Value.Date)
            'rpt.SetParameterValue("@d2", dtpDateTo.Value.Date)
            ' frmReport.CrystalReportViewer1.ReportSource = rpt
            ' frmReport.ShowDialog()
            myConnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub

End Class