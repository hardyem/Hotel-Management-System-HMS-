﻿Imports System.Data.SqlClient
Module modClasses
    Public con As SqlConnection = Nothing
    Public cmd As SqlCommand = Nothing
    Public rdr As SqlDataReader = Nothing
    Public ds As DataSet
    Public adp As SqlDataAdapter
    Public dtable As DataTable
End Module