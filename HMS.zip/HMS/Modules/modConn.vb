﻿Module modConn
    Public Const cs As String = "Data Source=DPROGRAMMER;Initial Catalog=HMS_DB;Integrated Security=True"
    'Public Const cs As String = "Data Source=.;AttachDbFileName=|DataDirectory|\Data\DB_POS.mdf;Initial Catalog=DB_POS;Integrated Security=True"
    'Original' ----
    'Public Const cs As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFileName=|DataDirectory|\Data\HMS_DB.mdf;Integrated Security=True"
End Module
